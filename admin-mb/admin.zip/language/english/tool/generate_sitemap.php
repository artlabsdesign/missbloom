<?php
// Heading
$_['heading_title']      = 'Generate Sitemaps';

// Text
$_['text_generate']      = 'Generate';
$_['text_success']       = 'Success: You have successfully generated sitemaps!';
$_['text_failure']       = 'Error: Please try again!';
$_['text_common']        = 'Press Generate button to generate sitemaps.';

// Buttons
$_['button_generate']    = 'Generate Sitemaps';
?>