<?php
// Heading
$_['heading_title']    = 'NitroPack 1.1.1 - Complete Web Performance Optimization Framework';

// Text
$_['text_success']     = '&nbsp;Success: You have successfully saved the settings! ';
$_['text_nopermission']     = 'You do not have permission to perform this action. Please contact the administrator of the store to provide you this privilege.';
?>