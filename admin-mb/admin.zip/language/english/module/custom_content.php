<?php
// Heading
$_['heading_title']       = '<span style="color:#ff0551;">ULTIMATUM</span> Custom Content module';
$_['doc_title']       = 'ULTIMATUM Custom Content';

// Text
$_['text_module']         = 'Modules';
$_['text_success']        = 'Success: You have modified module Custom Content!';
$_['text_content_top']    = 'Content Top';
$_['text_content_bottom'] = 'Content Bottom';
$_['text_column_left']    = 'Column Left';
$_['text_column_right']   = 'Column Right';
$_['text_browse']         = 'Browse';
$_['text_clear']          = 'Clear';
$_['text_title']          = 'Title: ';
$_['text_link']           = 'Link: ';
$_['text_image_manager']  = 'Image manager:';

// Entry
$_['button_add_section']   = 'Add Section';

// Entry
$_['entry_dimension']     = 'Slider Dimension: (W x H)';
$_['entry_image_dimension']= 'Image dimension: (W x H)';
$_['entry_image']         = 'Image:';
$_['entry_description'] = 'Module content:';
$_['entry_layout']        = 'Layout:';
$_['entry_position']      = 'Position:';
$_['entry_status']        = 'Status:';
$_['entry_sort_order']    = 'Sort Order:';

// Error
$_['error_permission']    		   = 'Warning: You do not have permission to modify module Custom Content!';
$_['error_slidero_dimension']    = 'Dimension - required!';
$_['error_image_dimension']        = 'Image Dimension - required!';
$_['error_sections_image']         = 'Image - required!';
?>