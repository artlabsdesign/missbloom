<?php
// Heading
$_['heading_title']                = '<span style="color:#ff0551;">ULTIMATUM</span> EasyBlog Installation';
$_['doc_title']       = 'ULTIMATUM EasyBlog Installation';

// Button
$_['button_install_now']           = 'Install Now';

// Text
$_['text_success']                 = 'Success: You have installed ULTIMATUM EasyBlog system!';
$_['text_multilanguage']           = 'Multilanguage:';
?>