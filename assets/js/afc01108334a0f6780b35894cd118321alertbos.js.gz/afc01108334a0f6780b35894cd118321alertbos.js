$(document).ready(function(){
	alert('sadasdasd');
	
	
});	