$(document).ready(function(){
	$('div#container').after('<script type="text/javascript" src="catalog/view/theme/ULTIMATUM/js/bootbox.min.js"></script>');
	
	
});	